import User from '#models/user'
import { registerValidator, loginValidator } from '#validators/auth'
import type { HttpContext } from '@adonisjs/core/http'

export default class AuthController {
  async register({ request, response }: HttpContext) {
    const data = await request.validateUsing(registerValidator)
    const user = await User.create(data)
    const token = await User.accessTokens.create(user)
    return response.status(201).json({ user, token })
  }

  async login({ request, response }: HttpContext) {
    const { email, password } = await request.validateUsing(loginValidator)
    const user = await User.verifyCredentials(email, password)
    const token = await User.accessTokens.create(user)
    return response.ok({ user, token })
  }

  async destroy({ auth, params, response }: HttpContext) {
    const user = auth.getUserOrFail()
    const category = await Category.query()
      .where('id', params.id)
      .where('user_id', user.id)   // ← langsung filter sekaligus
      .first()
    if (!category) return response.notFound({ message: 'Kategori tidak ditemukan' })
    await category.delete()
    return response.ok({ message: 'Kategori berhasil dihapus' })
  }
}
